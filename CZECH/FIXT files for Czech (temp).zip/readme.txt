-------------------------------------------------
INSTRUCTIONS FOR TRANSLATORS & TRANSLATIONS:
-------------------------------------------------

1) Unless we discussed otherwise, you should see folders and files for:
    - original English files (of v1.2 Fallout)
    - files in your langauge
    - files from FIXT


2) If you don't use them already, the programs Windows Grep, Beyond Compare, and FolderMatch are very useful.
   I've also heard good things about Ultra Edit although I don't personally use it.

	BEYOND COMPARE:  http://www.scootersoftware.com/download.php
	WINDOWS GREP:  http://www.wingrep.com/download.htm
	FOLDERMATCH:  http://www.foldermatch.com/fmdownload.htm
	ULTRA EDIT:  http://www.ultraedit.com/downloads.html

   If you know of a better program or other useful ones, please let me know.


3) Some files have been renamed. If you compare folders, that's why you will see these differences.
   Please use these filenames, so that filenames match with FIXT.

"ASSBLOW" renamed to "KALNOR"


4) Some files (such as TRAIT.MSG and PERK.MSG) are missing from the folder GAME. You will find these in subfolders within GAME folder.
   ***Please translate both copies of the file. Either of them is chosen by user during install so they both need to be translated.***
   Usually they are not much different, you can compare which parts differ with BeyondCompare.


5) I would prefer all ".MSG" files translated, but if you don't want to translate the demo files that's fine. They aren't currently used.
   These are the demo files:
 - BAKA.MSG
 - Anything with "DEMO" in the file name.
 - LENNY.MSG
 - LEX.MSG
 - PEZ.MSG
 - PHRAX.MSG
 - RAYZE.MSG
 - ROCK.MSG
 - SKIPPY.MSG
 - SKIZZER.MSG


6) You can probably skip the file CHEATER.MSG - these are only used if player is cheating/debugging for testing.


7) Let me know what name or username you want to be called in the credits.txt file :)


8) I will update these files periodically as I continue working on FIXT. (because these are not final, until the next version is actually released)



======================================================
======================================================
======================================================
NOTES-TO-SELF FOR SDUIBEK, IGNORE ALL OF THIS BELOW!
======================================================
======================================================
======================================================
delete perk.msg in txt/Game
delete trait.msg in txt/Game
make sure no backup files



